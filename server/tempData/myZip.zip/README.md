# To start website
1) `npm install`
2) `npm run build`
3) `npm start`
