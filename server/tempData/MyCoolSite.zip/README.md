# To start website
- 1) `npm install`
- 2) `npm start`


# OTHER OPTION:
- 1) `npm install`
- 2) `webpack -d`
- 3) `node server.js`